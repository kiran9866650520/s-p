define(function(){
    var message = "welcome to your life";
    var heroes = ko.observableArray([]);
    var callFun = function(){
        alert("you clicked me");
    };
    var activate = function(){
        var self = this;
        // console.log("view activated");
        $.get("https://jsonplaceholder.typicode.com/users")
            .success(function(r,s,x){
                // console.log(r)
               //  self.heroes = r;
               //  console.log(self.heroes)
                for(var i = 0 ; i < r.length ; i++){
                    console.log("user found")
                }
               // self.heroes.push()
            })
            .error(function(e,s,x){
                console.log(e)
            })

    };
    var binding = function(){
        console.log("view binding done");
    };
    var attached = function(){
        console.log("view attached");
    };

    return{
        msg : message,
        heroes : heroes,
        binding : binding,
        attached : attached,
        callFun : callFun,
        activate : activate

    }
});

hero.walk = function(){
	return 10
}
hero.fly = function(){
	return "hero is flying"
}
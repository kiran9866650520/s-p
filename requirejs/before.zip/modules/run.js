hero.run = function(){
	return hero.walk() * 20
}